const WebSocket = require('ws');
const prompt = require('prompt-sync')({ sigint: true });

const wsClient = new WebSocket("ws://localhost:5000");

wsClient.on("message", (msg) => {
    console.log(''+msg);
    let msg = prompt('Invia un messaggio >\n');
    wsClient.send(messaggio);
});
socket.on("open", function() {
    socket.send("ciao");
    socket.send(5);
 }) 