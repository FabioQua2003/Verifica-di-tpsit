const WebSocket = require("ws"); 
const PORT = 5000;
const clients = []; // creiamo un array di clients
var mode = 0;
const wsServer = new WebSocket.Server({
    port: PORT
});
console.log("Il Server è attivo e aspetta pacchetti sulla porta " + wsServer.options.port );

// funzione del fattoriale
function fattoriale(message) {
    for (let i = 1; i <= message; i++) {
        result *= i;
    }
}

wsServer.on("connection" , function(socket) {
    // console.log("un client si è appena connesso, i dati del client sono: ");
    clients.push(socket); // aggiungiamo con push il client nell'array
    socket.on("message" , function(msg) {
        switch (''+msg)  {
            case 'moltiplica' :
                mode = 1;
                clients.forEach(client => client.send(' moltiplicati'));
                break;
            case 'raddoppia':
                mode = 2;
                clients.forEach(client => client.send('raddoppiati'));
                break;
            case 'fattoriale' :
                mode = 3;
                clients.forEach(client => client.send('fattorizzati'));
                break;
            default :
                console.log("Messaggio non considerato .. ");
                break;  
        }
        console.log(mode);
        console.log(''+msg);
        switch (mode) {
            case 1 :
                if (isNaN(msg) == false) {
                    clients.forEach(client => client.send(`Echo: ${msg * msg}`));
                }
                break;
            case 2 :
                if (isNaN(msg) == false) {
                    clients.forEach(client => client.send(`Echo: ${msg * 2}`));
                }
                break;
            case 3 :
                if (isNaN(msg) == false) {
                    clients.forEach(client => client.send(`Echo: ${Fattoriale(msg)}`));
                }
                break;
            default :
                break;  
        }
    });
});
